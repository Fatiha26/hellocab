<div class="top-header">
     <div class="row">
         <div class="col-md-6">
              +88 00000
         </div>
         <div class="col-md-6">
         <i class="fa-brands fa-facebook-f"></i>
          <i class="fa-brands fa-twitter"></i>
          <i class="fa-brands fa-instagram"></i>
          <i class="fa-brands fa-telegram"></i>
         </div>
     </div>
</div>