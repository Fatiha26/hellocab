<div class="profile_nav">
  <ul>
    <li><a href="my_booking.php">My Booking</a></li>
    <li><a href="logout.php">Sign Out</a></li>
  </ul>
</div>
</div>